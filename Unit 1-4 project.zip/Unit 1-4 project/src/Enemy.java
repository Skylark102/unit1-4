
/** The class for the enemy, creates enemy objects that act as enemies in-game. */
class Enemy {

    /** Keeps track of the enemy's health*/
    private int enemyHP;
    /**How much damage the enemy can deal when attacking */
    private int enemyAttackValue;




    /** how good the enemy is at dodging attacks */
    private int enemyAgility;





    /** constructor /
     *
     * @param enemyHP parameter that sets the enemy's health.
     * @param enemyAttackValue parameter that sets the enemy's attack.
     * @param enemyAgility parameter that sets the enemy's agility.
     */
    public Enemy(int enemyHP, int enemyAttackValue, int enemyAgility) { //constructor with parameters that allows the enemy's attributes to be set.
        this.enemyHP = enemyHP;
        this.enemyAttackValue = enemyAttackValue;
        this.enemyAgility = enemyAgility;
    }

    /** An overloaded constructor that creates enemy obj. with preset values
     *
     * */

    public Enemy() { //overloaded constructor: this empty constructor creates an enemy object with pre-set attributes.
        enemyHP = 65;
        enemyAttackValue = 19;
        enemyAgility = 20;
    }


    /** getter method that returns enemy health
     *
     * @return returns enemyHP variable for the enemy's health.
     */
    public int enemyHealth() {
        return enemyHP;
    }

    /** void method to increase enemy's HP by the parameter input value
     *
     * @param num the amount to increase the enemy's health by.
     */
    public void increaseHP(int num) {
        enemyHP += num;
    }

    /** void method to decrease enemy's HP by the parameter input value
     *
     * @param num the amount to decrease the enemy's health by.
     */
    public void decreaseHP(int num) {
        enemyHP -= num;
    }

    /** void method to decrease enemy's agility by the parameter input value
     *
     * @param num the amount to decrease the enemy's agility by.
     */
    public void decreaseAglity(int num) {
        enemyAgility -= num;
    }

    /** getter method that returns the damage the enemy has dealt in an attack.
     *
     * @return enemyAttackValue is returned, representing how much damage the enemy has dealt in an attack.
     */
    public int getEnemyAttack() {
        return enemyAttackValue;
    }

    /** getter method that returns a boolean representing whether or not the enemy has dodged the player's attack
     *
     * @return returns whether or not the enemy dodged the player's attack.
     */
    public boolean getDodgeStatus() {
        return dodge();
    }

    /** void method that lets the enemy attack the player. Nothing is done if the enemy's health is below zero (dead). If the player dodges the attack, zero damage is dealt, if the player defends in his turn, the attack deals half damage, if all other conditions are false and the enemy is alive, the player's health is deducted by the enemy attack value.
     * @param target the target that the enemy is attacking
     * @param doesTargetDodge does the target dodge the attack? if yes, only half damage is dealt to the target.
     *
     * */
    public void attack(Player target, boolean doesTargetDodge) {
        if (enemyHealth() > 0) {
            if (doesTargetDodge == true) target.decreaseHP(0);
            if (doesTargetDodge == false) {
                if (target.getDefenderStatus() == false) target.decreaseHP(enemyAttackValue);
                if (target.getDefenderStatus() == true) target.decreaseHP(enemyAttackValue / 2);

            }
            else if (target.getDefenderStatus() == true && doesTargetDodge == false) {
                target.decreaseHP(enemyAttackValue / 2);
            }}

    }

    /** Calculates whether or not the enemy dodges the attack by probability provided by the EnemyAgility variable, which represents the percentage chance the enemy is able to dodge an attack
     * @return returns true if attack is dodged, returns false if attack is not dodged.
     *
     * */
    public boolean dodge() {
        if (Math.random() * 100 > enemyAgility) {
            return false;
        } else {
            return true;
        }
    }
}

