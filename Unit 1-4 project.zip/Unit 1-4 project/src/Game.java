import java.util.Scanner;
public class Game {

    private boolean didWinFirstRound;
    private Scanner scan = new Scanner(System.in);


    public Game() { //no parameter constructor
    }

    private void commandMenu() {
        System.out.print("It's your turn! Press the Corresponding Numbers to choose an action! \n");
        System.out.print("------------------------------------------------------------- \n");
        System.out.print("|  1. Attack         2. Defend    3. Spell   \n");
        System.out.print("------------------------------------------------------------- \n");
    }

  /*CHOICES IN THE COMMAND MENU:
      The command menu pops up when it is your turn to attack the enemy.
      You have 3 choices:
        1. Attack: Attack the enemy.
        2. Defend: Don't attack the enemy but go into defense mode so the enemy's next attack damage will be halved.
        3. Spell: Cast a spell to sabotage the enemy.
  */


    //start Game
    public void play() {
        Player p1 = new Player();
        Enemy e1 = new Enemy(50, 15, 30);




        System.out.println("Hello! Enter your name!");
        String newName = scan.nextLine();
        p1.setName(newName);

        System.out.println("You need to defeat this Enemy! ");
        int roundTracker = 0;
        boolean endGame = false;

        while (e1.enemyHealth() > 0 && roundTracker <= 10) {

            for (int rounds = 1; rounds <= 10 && e1.enemyHealth() > 0 && p1.playerHealth() > 0; rounds++) {
                roundTracker++;
                // Players Turn
                // Player + Enemy Health Check + Command Menu
                System.out.println("It is round " + rounds + ", " + (10 - rounds) + " rounds remaining!" );
                System.out.println("The Enemy has " + e1.enemyHealth() + " HP!");
                System.out.println("You have " + p1.playerHealth() + " HP!");
                commandMenu();
                // Player Choice Selection
                int choice = scan.nextInt();
                if (choice < 1 || choice >  3) {
                    System.out.println("Invalid Number! Choose 1, 2, or 3");
                }
                // Attack
                if (choice >= 1 && choice <= 3) {

                    if (choice == 1) {
                        boolean enemyDodgeVariable = e1.getDodgeStatus();
                        if (enemyDodgeVariable == true) {System.out.println("The enemy dodged the attack! You dealt zero damage! "); }
                        else {System.out.println("You attacked the enemy for " + p1.getPlayerAttack() + " Damage!");
                            p1.attack(e1, enemyDodgeVariable);}
                    }
                    // Defend
                    if (choice == 2) {
                        System.out.println("You brace for an attack! Take less damage!");
                        p1.setDefendMove(true);
                    }
                    // Spell
                    if (choice == 3) {
                        System.out.println("Your current Mana is:");
                        p1.manaShow();
                        System.out.println("What spell do you want to use?" + "\n" + "Press 4 for fire: attack the enemy and deal double damage;" + "\n" + "Press 5 to heal yourself;" + "\n" + "Press 6 to stun the enemy;" + "\n" + "Press 7 to increase your Agility. ");
                        int whichSpell = scan.nextInt();
                        p1.manaDecrease();
                        if (whichSpell == 4) {
                            System.out.println("Fire away! You use the fire spell to deal " + (p1.getPlayerAttack() * 2) + " damage!!");

                            p1.fire(e1);
                        }

                        if (whichSpell == 5) {
                            System.out.println("Be extra careful! You heal 20 HP!");
                            p1.heal();
                        }

                        if (whichSpell == 6) {
                            System.out.println("You stun the enemy! Decreasing their agility by 15!");
                            p1.stun(e1);
                        }

                        if (whichSpell == 7) {
                            System.out.println("Gotta go fast! You increase your Agility by 10!");
                            p1.agilityUp();
                        }

                    }

                    // Enemies Turn
                    if (e1.enemyHealth() > 0) {
                        System.out.println("Enemy's Turn!");
                        boolean playerDodgeVariable = p1.getDodgeStatus();
                        if (playerDodgeVariable == true) {
                            System.out.println("You dodge the enemy's attack!");
                        }
                        else if (p1.getDefenderStatus() == true && (e1.enemyHealth() > 0)) {
                            System.out.println("Enemy attacks you for " + e1.getEnemyAttack() / 2 + " damage!");
                        }
                        else {

                            if (e1.enemyHealth() > 0) System.out.println("Enemy attacks you for " + e1.getEnemyAttack() + " Damage!");
                        }
                        e1.attack(p1, playerDodgeVariable);
                    }
                }

            }

            break;
        }
        if (e1.enemyHealth() <= 0) {
            System.out.println("You defeated the enemy! You win!");
            didWinFirstRound = true;
        }
        else if (p1.playerHealth() <=0) {
            System.out.println("You die! Game Over!");
            didWinFirstRound = false;
        }
        else if (roundTracker == 10) {
            System.out.println("Neither you or the enemy died, stalemate!");
            didWinFirstRound = false;







        }
    }




    public void playGame2() { //a duplicate play method that plays the game with a new enemy created by the overloaded constructor; This enemy is harder to beat.
        if (didWinFirstRound == true)
        {
            Player p1 = new Player();
            Enemy e1 = new Enemy();

            System.out.println("A new enemy emerges! The enemy has more health and a stronger attack! defeat him!");
            System.out.println("You need to defeat this Enemy! ");
            int roundTracker = 0;
            boolean endGame = false;

            while (e1.enemyHealth() > 0 && roundTracker <= 10) {

                for (int rounds = 1; rounds <= 10 && e1.enemyHealth() > 0 && p1.playerHealth() > 0; rounds++) {
                    roundTracker++;
                    // Players Turn
                    // Player + Enemy Health Check + Command Menu
                    System.out.println("It is round " + rounds + ", " + (10 - rounds) + " rounds remaining!" );
                    System.out.println("The Enemy has " + e1.enemyHealth() + " HP!");
                    System.out.println("You have " + p1.playerHealth() + " HP!");
                    commandMenu();
                    // Player Choice Selection
                    int choice = scan.nextInt();
                    if (choice < 1 || choice >  3) {
                        System.out.println("Invalid Number! Choose 1, 2, or 3");
                    }
                    // Attack
                    if (choice >= 1 && choice <= 3) {

                        if (choice == 1) {
                            boolean enemyDodgeVariable = e1.getDodgeStatus();
                            if (enemyDodgeVariable == true) {System.out.println("The enemy dodged the attack! You dealt zero damage! "); }
                            else {System.out.println("You attacked the enemy for " + p1.getPlayerAttack() + " Damage!");
                                p1.attack(e1, enemyDodgeVariable);}
                        }
                        // Defend
                        if (choice == 2) {
                            System.out.println("You brace for an attack! Take less damage!");
                            p1.setDefendMove(true);
                        }
                        // Spell
                        if (choice == 3) {
                            System.out.println("Your current Mana is:");
                            p1.manaShow();
                            System.out.println("What spell do you want to use?" + "\n" + "Press 4 for fire: attack the enemy and deal double damage;" + "\n" + "Press 5 to heal yourself;" + "\n" + "Press 6 to stun the enemy;" + "\n" + "Press 7 to increase your Agility. ");
                            int whichSpell = scan.nextInt();
                            p1.manaDecrease();
                            if (whichSpell == 4) {
                                System.out.println("Fire away! You use the fire spell to deal " + (p1.getPlayerAttack() * 2) + " damage!!");

                                p1.fire(e1);
                            }

                            if (whichSpell == 5) {
                                System.out.println("Be extra careful! You heal 20 HP!");
                                p1.heal();
                            }

                            if (whichSpell == 6) {
                                System.out.println("You stun the enemy! Decreasing their agility by 15!");
                                p1.stun(e1);
                            }

                            if (whichSpell == 7) {
                                System.out.println("Gotta go fast! You increase your Agility by 10!");
                                p1.agilityUp();
                            }

                        }

                        // Enemies Turn
                        if (e1.enemyHealth() > 0) {
                            System.out.println("Enemy's Turn!");
                            boolean playerDodgeVariable = p1.getDodgeStatus();
                            if (playerDodgeVariable == true) {
                                System.out.println("You dodge the enemy's attack!");
                            }
                            else if (p1.getDefenderStatus() == true && (e1.enemyHealth() > 0)) {
                                System.out.println("Enemy attacks you for " + e1.getEnemyAttack() / 2 + " damage!");
                            }
                            else {

                                if (e1.enemyHealth() > 0) System.out.println("Enemy attacks you for " + e1.getEnemyAttack() + " Damage!");
                            }
                            e1.attack(p1, playerDodgeVariable);
                        }
                    }

                }

                break;
            }
            if (e1.enemyHealth() <= 0) System.out.println("You defeated the enemy! You win!");
            else if (p1.playerHealth() <=0) System.out.println("You die! Game Over!");
            else if (roundTracker == 10) {
                System.out.println("Neither you or the enemy died, stalemate!");







            }
        }
        else System.out.println("You failed to defeat the first enemy and so cannot face the seocnd enemy! Game over!");









    }




















}
