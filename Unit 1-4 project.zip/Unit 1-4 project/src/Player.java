class Player {
    private String playerName;
    private int playerHP;
    private int playerAttackValue; //how much damage the player can deal when attacking
    private int playerAgility; //how good the player is at dodging attacks (value ranges from 1 to 100, represents percent change of dodging an attack)
    private int playerAccuracy; //how accurately the player attacks the enemy, if your accuracy is greater than the enemy's agility, you successfully land the attack. Same is true for when the enemy attacks.
    private boolean isPlayerDefend = false;
    private String manaBar; //How many times your spells can be used. Represented as a visual bar in String form.



    // Player Constructor
    public Player() {
        playerHP = 50;
        playerAttackValue = 20;
        playerAgility = 50;
        manaBar = "□□□□□";
    }

    // Player Mana
    public void manaShow() {
        System.out.println(manaBar);
    }

    public String getManaBar() {
        return manaBar;
    }

    public void manaDecrease() {
        manaBar = manaBar.substring(1,manaBar.length());
    }

    // Player Spell List
    public void fire(Enemy target) {
        target.decreaseHP(playerAttackValue * 2);
    }

    public void heal() {
        playerHP += 20;
    }

    public void stun(Enemy target) {
        target.decreaseAglity(15);
    }

    public void agilityUp() {
        playerAgility += 10;
    }

    // Player Uses Spell
    public void useSpell(int whichSpell) {
        manaBar = manaBar.substring(1,manaBar.length());
        if (whichSpell == 1) {
            System.out.println("Fire away! You use the fire spell to deal double damage!!");
        }
    }


    // Player Info
    public void setName(String name){
        playerName = name;
    }

    public int playerHealth() {
        return playerHP;
    }

    // Change Player Variables
    public void increaseHP(int num) {
        playerHP += num;
    }

    public void decreaseHP(int num) {
        playerHP -= num;
    }

    // Get Player Attack
    public int getPlayerAttack() {
        return playerAttackValue;
    }

    // Player Defense
    public void setDefendMove(boolean trueOrFalse) {
        isPlayerDefend = trueOrFalse;
    }

    public boolean getDefenderStatus() {
        return isPlayerDefend;
    }

    public boolean getDodgeStatus() {
        return dodge();
    }

    // Player Attacks
    public void attack(Enemy target, boolean doesTargetDodge) {
        if (doesTargetDodge == true) target.decreaseHP(0);
        else target.decreaseHP(playerAttackValue);
    }

    // Player Dodge
    public boolean dodge() {
        if (Math.random() * 100 > playerAgility) {
            return false;
        } else {
            return true;
        }
    }





}